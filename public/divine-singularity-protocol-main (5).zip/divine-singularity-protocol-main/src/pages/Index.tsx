
import React from 'react';
import OmniOracleDashboard from "@/components/OmniOracleDashboard";

const Index: React.FC = () => {
  return <OmniOracleDashboard />;
};

export default Index;
