
// Re-export from the new location
export { QuantumDiagnostics } from './diagnostics/index';
export type { DiagnosticResult } from './diagnostics/types';
